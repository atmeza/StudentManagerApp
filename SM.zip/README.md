This is CSE 110 Fall 2016 Group 2's GROUP PROJECT!

This app will be an all purpose student manager.